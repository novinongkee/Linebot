# bot client
~ login with email account
~ for tutorial please watch and subscribe my chanel youtube https://www.youtube.com/channel/UCIgeVnn7uAVNDGtb1MqnEWw/videos
# open order
~ jika anda tidak betah pusing silahkan order saja ke id line - castello_bardian
